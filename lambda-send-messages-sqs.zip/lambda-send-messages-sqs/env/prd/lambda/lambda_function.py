import os
import boto3
import json

# Crie um cliente boto3 para S3 e SQS
s3 = boto3.client('s3')
sqs = boto3.client('sqs')

def lambda_handler(event, context):
    # Obtenha o nome do bucket da variável de ambiente
    bucket_name = os.getenv('BUCKET_NAME')
    
    # Obtenha os nomes dos arquivos da variável de ambiente
    file_names = os.getenv('FILE_NAMES').split(',')
    
    # Obtenha o queue url da variável de ambiente
    queue_url = os.getenv('QUEUE_URL')    
      
    # Itere sobre os nomes dos arquivos
    for file_name in file_names:
        try:
            # Obtenha o objeto do arquivo do bucket
            file_obj = s3.get_object(Bucket=bucket_name, Key=file_name)
            
            # Leia o conteúdo do arquivo
            file_content = file_obj['Body'].read().decode('utf-8')
            
            # Carregue o conteúdo JSON
            json_content = json.loads(file_content)
            
            # Itere sobre os itens no conteúdo JSON
            for item in json_content:
                msgBody = json.dumps(item)
                
                # Enviar mensagem para a fila SQS
                response = sqs.send_message(
                    QueueUrl=queue_url,
                    MessageBody=msgBody
                )
                print(f"Mensagem enviada: {msgBody}")
        
        except json.JSONDecodeError as e:
            print(f"Erro ao decodificar JSON no arquivo {file_name}: {e}")
        except Exception as e:
            print(f"Erro ao processar o arquivo {file_name}: {e}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('As mensagens foram enviadas com sucesso para a fila SQS.')
    }